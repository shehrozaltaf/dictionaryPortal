<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
ERROR - 2020-04-21 10:32:58 --> 404 Page Not Found: Assets/vendors
ERROR - 2020-04-21 10:32:58 --> 404 Page Not Found: Assets/vendors
ERROR - 2020-04-21 10:33:00 --> 404 Page Not Found: Assets/vendors
ERROR - 2020-04-21 10:33:01 --> 404 Page Not Found: Assets/vendors
ERROR - 2020-04-21 10:33:19 --> 404 Page Not Found: Assets/vendors
ERROR - 2020-04-21 10:33:20 --> 404 Page Not Found: Assets/vendors
ERROR - 2020-04-21 13:33:50 --> Severity: error --> Exception: Call to undefined method Custom::getIP() C:\xampp\htdocs\dictionary_portal\application\models\Custom.php 74
ERROR - 2020-04-21 11:08:03 --> Query error: Unknown column 'section_details.child_seq_no' in 'order clause' - Invalid query: SELECT `crf`.`crf_name`, `section_detail`.`variable_name`, `section_detail`.`label_l1`, `section_detail`.`label_l2`, `section_detail`.`option_value`, `section_detail`.`dbType`, `section`.`tableName`, `section_detail`.`insertDB`, `section_detail`.`idParentQuestion`, `section_detail`.`dbLength`, `section_detail`.`nature`
FROM `section_detail`
RIGHT JOIN `section` ON `section_detail`.`idSection` =`section`.`idSection`
LEFT JOIN `modules` ON `section`.`idModule` = `modules`.`idModule`
LEFT JOIN `crf` ON `modules`.`id_crf` = `crf`.`id_crf`
WHERE `crf`.`idProjects` = '12'
AND `section`.`idSection` = '43'
AND `section_detail`.`nature` != 'Title' 
AND `section`.`isActive` = 1
AND `section_detail`.`isActive` = 1
ORDER BY `section_detail`.`variable_name` ASC, `section_detail`.`seq_no` ASC, `section_details`.`child_seq_no` ASC
ERROR - 2020-04-21 11:13:59 --> Query error: Unknown column 'section_detail.idParent' in 'where clause' - Invalid query: SELECT `section_detail`.`variable_name`, `section_detail`.`label_l1`
FROM `section_detail`
RIGHT JOIN `section` ON `section_detail`.`idSection` =`section`.`idSection`
LEFT JOIN `modules` ON `section`.`idModule` = `modules`.`idModule`
LEFT JOIN `crf` ON `modules`.`id_crf` = `crf`.`id_crf`
WHERE `crf`.`idProjects` = '12'
AND `section`.`idSection` = '43'
AND `section_detail`.`nature` != 'Title' 
AND `section`.`isActive` = 1
AND `section_detail`.`isActive` = 1
AND `section_detail`.`idParent` = ''
ORDER BY `section_detail`.`variable_name` ASC, `section_detail`.`seq_no` ASC, `section_detail`.`child_seq_no` ASC
ERROR - 2020-04-21 14:46:50 --> Query error: Table 'dictionary_portalnew.crfs' doesn't exist - Invalid query: SELECT `section_detail`.`variable_name`, `section_detail`.`label_l1`
FROM `section_detail`
RIGHT JOIN `section` ON `section_detail`.`idSection` =`section`.`idSection`
LEFT JOIN `modules` ON `section`.`idModule` = `modules`.`idModule`
LEFT JOIN `crfs` ON `modules`.`id_crf` = `crf`.`id_crf`
WHERE `crf`.`idProjects` = '12'
AND `section`.`isActive` = 1
AND `section_detail`.`isActive` = 1
AND `section_detail`.`idParentQuestion` = ''
ORDER BY `section_detail`.`variable_name` ASC, `section_detail`.`seq_no` ASC, `section_detail`.`child_seq_no` ASC
ERROR - 2020-04-21 14:52:15 --> Query error: Table 'dictionary_portalnew.crfs' doesn't exist - Invalid query: SELECT `section_detail`.`variable_name`, `section_detail`.`label_l1`
FROM `section_detail`
RIGHT JOIN `section` ON `section_detail`.`idSection` =`section`.`idSection`
LEFT JOIN `modules` ON `section`.`idModule` = `modules`.`idModule`
LEFT JOIN `crfs` ON `modules`.`id_crf` = `crf`.`id_crf`
WHERE `crf`.`idProjects` = '12'
AND `section`.`isActive` = 1
AND `section_detail`.`isActive` = 1
AND `section_detail`.`idParentQuestion` = ''
ORDER BY `section_detail`.`variable_name` ASC, `section_detail`.`seq_no` ASC, `section_detail`.`child_seq_no` ASC
ERROR - 2020-04-21 14:54:02 --> Query error: Table 'dictionary_portalnew.crfs' doesn't exist - Invalid query: SELECT `section_detail`.`variable_name`, `section_detail`.`label_l1`
FROM `section_detail`
RIGHT JOIN `section` ON `section_detail`.`idSection` =`section`.`idSection`
LEFT JOIN `modules` ON `section`.`idModule` = `modules`.`idModule`
LEFT JOIN `crfs` ON `modules`.`id_crf` = `crf`.`id_crf`
WHERE `crf`.`idProjects` = '12'
AND `section`.`isActive` = 1
AND `section_detail`.`isActive` = 1
AND (`section_detail`.`idParentQuestion` is null  or `section_detail`.`idParentQuestion` = '')
ORDER BY `section_detail`.`variable_name` ASC, `section_detail`.`seq_no` ASC, `section_detail`.`child_seq_no` ASC
ERROR - 2020-04-21 14:54:31 --> Query error: Table 'dictionary_portalnew.crfs' doesn't exist - Invalid query: SELECT `section_detail`.`variable_name`, `section_detail`.`label_l1`
FROM `section_detail`
RIGHT JOIN `section` ON `section_detail`.`idSection` =`section`.`idSection`
LEFT JOIN `modules` ON `section`.`idModule` = `modules`.`idModule`
LEFT JOIN `crfs` ON `modules`.`id_crf` = `crf`.`id_crf`
WHERE `crf`.`idProjects` = '12'
AND `section`.`isActive` = 1
AND `section_detail`.`isActive` = 1
AND (`section_detail`.`idParentQuestion` is null  or `section_detail`.`idParentQuestion` = '')
ORDER BY `section_detail`.`variable_name` ASC, `section_detail`.`seq_no` ASC, `section_detail`.`child_seq_no` ASC
ERROR - 2020-04-21 15:08:30 --> Severity: error --> Exception: Unable to locate the model you have specified: Mcustom C:\xampp\htdocs\dictionary_portal\system\core\Loader.php 348
ERROR - 2020-04-21 15:08:30 --> Severity: error --> Exception: Unable to locate the model you have specified: Mcustom C:\xampp\htdocs\dictionary_portal\system\core\Loader.php 348
ERROR - 2020-04-21 15:08:32 --> Severity: error --> Exception: Unable to locate the model you have specified: Mcustom C:\xampp\htdocs\dictionary_portal\system\core\Loader.php 348
ERROR - 2020-04-21 15:08:50 --> Severity: error --> Exception: Unable to locate the model you have specified: Mcustom C:\xampp\htdocs\dictionary_portal\system\core\Loader.php 348
ERROR - 2020-04-21 15:09:20 --> Severity: error --> Exception: Unable to locate the model you have specified: Mcustom C:\xampp\htdocs\dictionary_portal\system\core\Loader.php 348
ERROR - 2020-04-21 15:10:10 --> Severity: error --> Exception: Unable to locate the model you have specified: Mcustom C:\xampp\htdocs\dictionary_portal\system\core\Loader.php 348
ERROR - 2020-04-21 15:10:11 --> Severity: error --> Exception: Unable to locate the model you have specified: Mcustom C:\xampp\htdocs\dictionary_portal\system\core\Loader.php 348
ERROR - 2020-04-21 15:10:43 --> Severity: error --> Exception: Unable to locate the model you have specified: Mcustom C:\xampp\htdocs\dictionary_portal\system\core\Loader.php 348
